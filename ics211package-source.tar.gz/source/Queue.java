package ics211package;
public class Queue {
   private LinkedList myList;
   public Queue() {
      myList = new LinkedList();
   }
   @SuppressWarnings("unchecked")
   public <T> T dequeue() {
      T item = null;
      try {
         item = (T)myList.remove(myList.length()-1);
      }
      catch (ListException e) {
         e.printStackTrace();
      }
      return item;
   }
   @SuppressWarnings("unchecked")
   public <T> void enqueue(T item) {
      try {
         myList.insert(item,0);
      }
      catch (ListException e) {
         e.printStackTrace();
      }
   }
   public int length() {
      return myList.length();
   }
   public boolean isEmpty() {
      return myList.length() == 0;
   }
   public <T> T rotate() {
      T item = dequeue();
      enqueue(item);
      return item;
   }
   public void print() {
      for (int i = 0; i < myList.length(); i++) {
         try {
            System.out.print(myList.retrieve(i) + " ");
         }
         catch (ListException e) {
            e.printStackTrace();
         }
      }
      System.out.println("");
   }/*
   public void print() {
      System.out.println(myList);
   }*/
   public int size() {
      return myList.length();
   }
   public String toString() {
      String temp = "";
      for (int i = 0; i < myList.length(); i++) {
         try {
            temp += myList.retrieve(i);
            if (i < myList.length() - 1) {
               temp += " ";
            }
         }
         catch (ListException e) {
         }
      }
      return temp;
   }
   @SuppressWarnings("unchecked")
   public <T> T peek() {
      T item = null;
      try {
         item = (T)myList.retrieve(myList.length() - 1);
      }
      catch (ListException e) {
      }
      return item;
   }
}
