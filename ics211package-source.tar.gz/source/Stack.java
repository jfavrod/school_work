package ics211package;
public class Stack {
   private  LinkedList<Object> myList = null;
   public Stack() {
      myList = new LinkedList<Object>();
   }
   public boolean isEmpty() {
      return myList.isEmpty();
   }
   @SuppressWarnings("unchecked")
   public <T> void push(T item) {
      myList.append(item);
   }
   @SuppressWarnings("unchecked")
   public <T> T pop() {
      if (isEmpty()) {
         return null;
      }
      T poppedItem = null;
      try {
         poppedItem = (T)myList.remove(myList.length()-1);
      }
      catch (ListException e) {
      
      }
      return poppedItem;
   }
   @SuppressWarnings("unchecked")
   public <T> T peek() {
      T item = null;
      try {
         item = (T)myList.retrieve(myList.length()-1);
      }
      catch (ListException e) {
      
      }
      return item;
   }
   public int length() {
      return myList.length();
   }
   public void print() {
      for (int i = myList.length()-1; i >= 0; i--) {
         try {
            System.out.println(myList.retrieve(i));
         }
         catch (ListException e) {
            e.printStackTrace();
         }
      }
   }
   public String toString() {
      String temp = "";
      for (int i = myList.length() - 1; i >= 0; i--) {
         try {
            temp += myList.retrieve(i);
            if (i > 0) {
               temp += "\n";
            }
         }
         catch (ListException e) {
         }
      }
      return temp;
   }
}
