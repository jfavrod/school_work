package ics211package;
import java.util.Random;
public class ArrayShuffler {
   private static Random random;
   
   static {
      random = new Random(System.currentTimeMillis());
   }
   public static void shuffle(Object[] a) {
      int len = a.length;
      for (int i = 0; i < len; i++) {
         int r = i + random.nextInt(len-i);     // between i and len-1
         Object temp = a[i];
         a[i] = a[r];
         a[r] = temp;
      }
   }
   public static void shuffle(double[] a) {
      int len = a.length;
      for (int i = 0; i < len; i++) {
         int r = i + random.nextInt(len-i);     // between i and len-1
         double temp = a[i];
         a[i] = a[r];
         a[r] = temp;
      }
   }
   public static void shuffle(int[] a) {
      int len = a.length;
      for (int i = 0; i < len; i++) {
         int r = i + random.nextInt(len-i);     // between i and len-1
         int temp = a[i];
         a[i] = a[r];
         a[r] = temp;
      }
   }
   public static void shuffle(long[] a) {
      int len = a.length;
      for (int i = 0; i < len; i++) {
         int r = i + random.nextInt(len-i);     // between i and len-1
         long temp = a[i];
         a[i] = a[r];
         a[r] = temp;
      }
   }
}
