package ics211package;
public abstract class AbstractList
{
   protected AbstractList()
   {}
}
