public abstract class AbstractList
{
   protected AbstractList()
   {}
}
