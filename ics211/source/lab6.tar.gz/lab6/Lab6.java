/* Lab 
 *
 * By: Jason Favrod
 * 
 * This method runs faster than the recursive method because
 * instead of multiple recursive function calls that perform
 * many calculations and stores many function calls in memory,
 * this method runs a loop that only performs a single
 * calculation and manipulates only a couple of items in
 * memory.
 *
 * This method is on the order of n.
 *
 * I don't think this is the most efficient way to produce the
 * fibonacci series. I think maybe something can be done with
 * the increasing difference between the numbers.
 *
 * If I were to find a better method I could prove it was better
 * by comparing the run time, memory usage, and number of system
 * calls to find which method is more efficient.
 */

public class Lab6
{

    public static void main(String[] args) {
        try {
            int n = Integer.parseInt(args[0]); 
            if (n == 0) System.out.println("0");
            else System.out.println(fib(n));
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(fib(45));
        }
    }

    public static int fib(int n) {
        int count = n, tmp1 = 0, tmp2 = 0;
        Stack stack = new Stack();

        for (int i = 1; i <= count; i++) {
            if (stack.size() > 1) {
                tmp2 = (int)stack.pop();
                tmp1 = (int)stack.pop();
                stack.push(tmp1 + tmp2);
            }
            else if (stack.size() == 1) {
                tmp1 = (int)stack.peek();
                stack.push(tmp1 + tmp2);
            }
            else {
                stack.push(1);
            }
        }

        return (int)stack.pop();
    }
}


