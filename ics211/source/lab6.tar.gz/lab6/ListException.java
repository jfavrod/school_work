public class ListException extends Exception {
   public ListException() {
      super("Unspecified ListException");
   }
   public ListException(String message) {
      super(message);
   }
}
